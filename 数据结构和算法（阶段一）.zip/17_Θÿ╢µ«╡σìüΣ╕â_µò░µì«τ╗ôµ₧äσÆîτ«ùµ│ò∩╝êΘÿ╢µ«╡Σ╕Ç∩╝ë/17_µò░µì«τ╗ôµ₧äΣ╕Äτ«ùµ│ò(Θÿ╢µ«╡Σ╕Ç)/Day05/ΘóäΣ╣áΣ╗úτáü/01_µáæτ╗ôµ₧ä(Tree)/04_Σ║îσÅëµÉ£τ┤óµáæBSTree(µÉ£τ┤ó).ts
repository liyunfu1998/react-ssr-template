import Node from "../types/Node"

import { btPrint } from 'hy-algokit'

class TreeNode<T> extends Node<T> {
  left: TreeNode<T> | null = null
  right: TreeNode<T> | null = null

  parent: TreeNode<T> | null = null

  get isLeft() {
    return !!(this.parent && this.parent.left === this)
  }

  get isRight() {
    return !!(this.parent && this.parent.right === this)
  }
} 

class BSTree<T> {
  private root: TreeNode<T> | null = null

  private getSuccessor(delNode: TreeNode<T>) {
    // 从删除节点的右边 => 向左边去找
    let current = delNode.right
    let successor: TreeNode<T> | null = null
    while (current) {
      successor = current
      current = current.left
      if (current) {
        current.parent = successor
      }
    }

    // 如果是删除图15位置的节点, 需要额外进行的操作
    if (successor !== delNode.right) {
      successor!.parent!.left = successor?.right ?? null
      successor!.right = delNode.right
    }

    // 将删除节点的左节点, 放到后继节点的左边
    successor!.left = delNode.left
    return successor!
  }

  insert(value: T) {
    const newNode = new TreeNode(value)

    if (!this.root) {
      this.root = newNode
    } else {
      this.insertNode(this.root, newNode)
    }
  }

  private insertNode(node: TreeNode<T>, newNode: TreeNode<T>) {
    if (newNode.value < node.value) {
      if (node.left === null) {
        node.left = newNode
      } else {
        this.insertNode(node.left, newNode)
      }
    } else {
      if (node.right === null) {
        node.right = newNode
      } else {
        this.insertNode(node.right, newNode)
      }
    }
  }

  preOrderTraverse() {
    this.preOrderTraverseNode(this.root)
  }

  private preOrderTraverseNode(node: TreeNode<T> | null) {
    if (node) {
      console.log(node.value)
      this.preOrderTraverseNode(node.left)
      this.preOrderTraverseNode(node.right)
    }
  }

  inOrderTraverse() {
    this.inOrderTraverseNode(this.root)
  }

  private inOrderTraverseNode(node: TreeNode<T> | null) {
    if (node) {
      this.inOrderTraverseNode(node.left)
      console.log(node.value)
      this.inOrderTraverseNode(node.right)
    }
  }

  postOrderTraverse() {
    this.postOrderTraverseNode(this.root)
  }

  private postOrderTraverseNode(node: TreeNode<T> | null) {
    if (node) {
      this.postOrderTraverseNode(node.left)
      this.postOrderTraverseNode(node.right)
      console.log(node.value)
    }
  }

  levelOrderTraverse() {
    if (!this.root) return

    // root作为第一个放进去
    const queue: TreeNode<T>[] = [this.root]
    while (queue.length) {
      const current = queue.shift()!
      console.log(current.value)

      if (current.left) {
        queue.push(current.left)
      }
      if (current.right) {
        queue.push(current.right)
      }
    }
  }

  print() {
    btPrint(this.root)
  }

  getMinValue(): T | null {
    let current = this.root
    while (current && current.left) {
      current = current.left
    }
    return current?.value ?? null
  }

  getMaxValue(): T | null {
    let current = this.root
    while (current && current.right) {
      current = current.right
    }
    return current?.value ?? null
  }

  private searchNode(value: T): TreeNode<T> | null {
    let current = this.root
    let parent: TreeNode<T> | null = null
    while (current) {
      parent = current
      if (current.value === value) {
        return current
      } else if (current.value < value) {
        current = current.right
      } else {
        current = current.left
      }
      // 设置父节点
      if (current) {
        current.parent = parent
      }
    }
    return null
  }

  search(value: T) {
    return !!this.searchNode(value)
  }

  testSuccessor(value: T) {
    const node = this.searchNode(value)
    if (!node) return
    const successor = this.getSuccessor(node)
    console.log(successor?.value)
  }

  remove(value: T): boolean {
    if (!this.root) return false

    // 寻找要删除的节点
    const current = this.searchNode(value)
    if (!current) return false

    // 1.如果是没有子节点
    if (current.left === null && current.right === null) {
      if (current === this.root) {
        this.root = null
      } else if (current.isLeft) {
        current.parent!.left = null
      } else {
        current.parent!.right = null
      }
    }

    // 2.如果只有左子节点
    else if (current.right === null) {
      if (current === this.root) {
        this.root = current.left
      } else if (current.isLeft) {
        current.parent!.left = current.left
      } else {
        current.parent!.right = current.left
      }
    }

    // 3.如果只有右子节点
    else if (current.left === null) {
      if (current === this.root) {
        this.root = current.right
      } else if (current.isLeft) {
        current.parent!.left = current.right
      } else {
        current.parent!.right = current.right
      }
    }

    // 4.左右节点都有值
    else {
      let successor = this.getSuccessor(current)
      if (current === this.root) {
        this.root = successor
      } else if (current.isLeft) {
        current.parent!.left = successor
      } else {
        current.parent!.right = successor
      }
    }

    return true
  }
}

const bst = new BSTree<number>()
bst.insert(11)
bst.insert(7)
bst.insert(15)
bst.insert(5)
bst.insert(3)
bst.insert(9)
bst.insert(8)
bst.insert(10)
bst.insert(13)
// bst.insert(12)
bst.insert(14)
bst.insert(20)
bst.insert(18)
bst.insert(25)

bst.print()

// bst.preOrderTraverse()
// bst.inOrderTraverse()
// bst.postOrderTraverse()
// bst.levelOrderTraverse()

// console.log(bst.getMinValue())
// console.log(bst.getMaxValue())
// console.log(bst.search(3))
// console.log(bst.search(100))

// 测试后继节点
// bst.testSuccessor(11)
bst.remove(11)
bst.print()

export {}

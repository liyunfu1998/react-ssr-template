class Node<T=number> {
  value: T
  left: Node<T> | null
  right: Node<T> | null

  constructor(value: T) {
    this.value = value
    this.left = null
    this.right = null
  }
}

class BSTree<T = number> {
  root: Node<T> | null = null

  // 二叉搜索树的其他方法
  // 插入节点
  insert(value: T) {
    // 创建新的节点
    const newNode = new Node(value)

    // 判断是否有根节点
    if (!this.root) {
      this.root = newNode
    } else {
      this.insertNode(this.root, newNode)
    }
  }
  private insertNode(node: Node<T>, newNode: Node<T>) {
    if (newNode.value < node.value) { // 向左子树插入
      if (node.left === null) { // 左子树上没有内容
        node.left = newNode
      } else {
        this.insertNode(node.left, newNode)
      }
    } else { // 向右子树插入
      if (node.right === null) {
        node.right = newNode
      } else {
        this.insertNode(node.right, newNode)
      }
    }
  }
}

const bst = new BSTree()
bst.insert(11)
bst.insert(7)
bst.insert(15)
bst.insert(5)
bst.insert(3)
bst.insert(9)
bst.insert(8)
bst.insert(10)
bst.insert(13)
bst.insert(12)
bst.insert(14)
bst.insert(20)
bst.insert(18)
bst.insert(25)
bst.insert(6)

function printTree(node: Node | null, level = 0) {
  if (!node) return;
  printTree(node.right, level + 1);
  console.log(" ".repeat(level * 4) + node.value);
  printTree(node.left, level + 1);
}


function printTree2(root: Node | null) {
  const height = getHeight(root);

  const lines = new Array<string[]>(height);
  for (let i = 0; i < height; i++) {
      lines[i] = new Array<string>(Math.pow(2, height) - 1).fill("");
  }
  console.log(lines)

  fillTree(root, lines, 0, 0, lines[0].length - 1);
}

function fillTree(node: Node | null, lines: string[][], i: number, l: number, r: number) {
  if (!node) {
      return;
  }

  const m = Math.floor((l + r) / 2);
  lines[i][m] = node.value.toString();

  if (node.left) {
      lines[i + 1][m - 1] = "/";
      fillTree(node.left, lines, i + 2, l, m - 1);
  }

  if (node.right) {
      lines[i + 1][m + 1] = "\\";
      fillTree(node.right, lines, i + 2, m + 1, r);
  }
}

function getHeight(node: Node | null): number {
  if (!node) {
      return 0;
  }

  return 1 + Math.max(getHeight(node.left), getHeight(node.right));
}

function printTree3(node: Node | null, prefix: string = "", isTail: boolean = true) {
  if (!node) return;
  console.log(prefix + (isTail ? "└── " : "├── ") + node.value);
  let prefixNext = prefix + (isTail ? "    " : "│   ");
  if (node.left) {
    printTree3(node.left, prefixNext, false);
  }
  if (node.right) {
    printTree3(node.right, prefixNext, true);
  }
}

printTree3(bst.root)


export {}

class HashTable<T = any> {
  storage: [string, T][][] = []
  private count: number = 0
  private limit: number = 8

  private hashIndex(str: string, max: number): number {
    // 1.初始化hashCode
    let hashCode = 0
  
    // 2.霍纳算法, 计算hashCode的值
    for (let i = 0; i < str.length; i++) {
      hashCode = 31 * hashCode + str.charCodeAt(i)
    }
  
    // 3.通过取模计算索引值
    return hashCode % max
  }


  put(key: string, value: T) {
    // 1.根据key获取index
    const index = this.hashIndex(key, this.limit)

    // 2.取出对应位置的桶(bucket)
    let bucket = this.storage[index]
    if (!bucket) {
      bucket = []
      this.storage[index] = bucket
    }

    // 3.判断是新增还是修改原来的值
    let isCover = false
    for (let i = 0; i < bucket.length; i++) {
      const tuple = bucket[i]
      if (tuple[0] === key) {
        tuple[1] = value
        isCover = true
        break
      }
    }

    // 4.遍历完桶中所有的元素, 依然没有覆盖
    if (!isCover) {
      bucket.push([key, value])
      this.count++
      // 数组扩容
      if (this.count > this.limit * 0.75) {
        this.resize(this.limit * 2)
      }
    }
  }

  get(key: string): T | null {
    // 1.根据key获取索引
    const index = this.hashIndex(key, this.limit)

    // 2.根据索引获取桶bucket
    const bucket = this.storage[index]
    if (!bucket) {
      return null
    }

    // 3.遍历桶中的数据
    for (let i = 0; i < bucket.length; i++) {
      const tuple = bucket[i]
      if (tuple[0] === key) {
        return tuple[1]
      }
    }

    return null
  }


  delete(key: string): T | null {
    // 1.根据key获取index
    const index = this.hashIndex(key, this.limit)

    // 2.获取bucket
    const bucket = this.storage[index]
    if (!bucket) return null

    // 3.遍历桶
    for (let i = 0;i < bucket.length; i++) {
      const tuple = bucket[i]
      if (tuple[0] === key) {
        bucket.splice(i, 1)
        this.count--

        // 数组缩小容量
        if (this.limit > 8 && this.count < this.limit * 0.25) {
          this.resize(Math.floor(this.limit / 2))
        }

        return tuple[1]
      }
    }

    return null
  }


  resize(newLimit: number) {
    // 1.保存旧数组中的内容
    const oldStorage = this.storage

    // 2.重置属性
    this.limit = newLimit
    this.count = 0
    this.storage = []

    // 3.遍历原来数组中的所有数据
    oldStorage.forEach(bucket => {
      // 3.1.如果没有数据, 那么直接返回
      if (!bucket) return

      // 3.2.bucket中有数据, 那么将所有数据重新hash
      for (let i = 0; i < bucket.length; i++) {
        const tuple = bucket[i]
        this.put(tuple[0], tuple[1])
      }
    })
  }
}

export default HashTable

import ArrayStack from './01_实现Stack'

function isValid(s: string): boolean {
  const stack = new ArrayStack<string>()
  const length = s.length
  for (let i = 0; i < length; i++) {
    switch (s[i]) {
      case "(":
        stack.push(")")
        break
      case "[":
        stack.push("]")
        break
      case "{":
        stack.push("}")
        break
      default:
        const curS = s[i]
        if (stack.pop() !== curS) return false
        break
    }
  }
  return stack.isEmpty()
}

console.log(isValid("()[]{}"))
console.log(isValid("(]"))

export {}
import { swap, testSort } from "./utils"
import { measureSort } from 'hy-algokit'

export default function quickSort(arr: number[]): number[] {
  function partition(left: number, right: number) {
    // 如果左右指针相当, 那么排序已经完成, 直接返回
    if (left >= right) return

    // 1.选择最后一个元素作为基准元素
    const pivot = arr[right]

    // 2.初始化左右指针
    let i = left
    let j = right - 1
    while (i <= j) {
      // 左指针向右移动, 直接找到一个大于或者等于基准元素的值
      while (arr[i] < pivot) {
        i++
      }
      // 右指针向左移动, 直接找到一个小于或者等于基准元素的值
      while (arr[j] > pivot) {
        j--
      }

      if (i <= j) {
        swap(arr, i, j)
        i++
        j--
      }
    }

    // 将轴点元素和放在总监位置
    swap(arr, i, right)

    // 递归的对左右两个子数组进行快速排序
    partition(left, j)
    partition(i, right)
  }

  partition(0, arr.length - 1)
  return arr
}

// testSort(quickSort)
// measureSort(quickSort)


function quickSort2(array: number[], left: number = 0, right: number = array.length - 1): number[] {
  if (left >= right) {
    return array;
  }

  // 三数取中法选取基准元素
  const pivot = median(array[left], array[right], array[Math.floor((left + right) / 2)]);

  let i = left;
  let j = right;

  while (i <= j) {
    while (array[i] < pivot) {
      i++;
    }
    while (array[j] > pivot) {
      j--;
    }
    if (i <= j) {
      [array[i], array[j]] = [array[j], array[i]];
      i++;
      j--;
    }
  }

  // 将基准元素移动到中间位置
  const mid = Math.floor((left + right) / 2);
  [array[mid], array[j + 1]] = [array[j + 1], array[mid]];

  quickSort2(array, left, j);
  quickSort2(array, i, right);

  return array;
}

function median(a: number, b: number, c: number): number {
  if (a > b) {
    [a, b] = [b, a];
  }
  if (b > c) {
    [b, c] = [c, b];
  }
  if (a > b) {
    [a, b] = [b, a];
  }
  return b;
}

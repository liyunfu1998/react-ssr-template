import { testSort } from './utils'

function bucketSort(array: number[], bucketSize = 5): number[] {
  const n = array.length;

  if (n < 2) return array

  // 确定桶的数量，和每个桶的范围
  const minValue = Math.min(...array);
  const maxValue = Math.max(...array);
  const bucketCount = Math.floor((maxValue - minValue) / bucketSize) + 1;

  // 将数组中的元素分配到各个桶中
  const buckets: number[][] = new Array(bucketCount);
  for (let i = 0; i < bucketCount; i++) {
    buckets[i] = [];
  }
  for (let i = 0; i < n; i++) {
    const bucketIndex = Math.floor((array[i] - minValue) / bucketSize);
    buckets[bucketIndex].push(array[i]);
  }

  // 对每个桶中的元素进行排序
  for (let i = 0; i < bucketCount; i++) {
    insertionSort(buckets[i]);
  }

  // 将所有的桶中的元素按照顺序合并到结果数组中
  let k = 0;
  const res = new Array(n);
  for (let i = 0; i < bucketCount; i++) {
    const bucket = buckets[i];
    for (let j = 0; j < bucket.length; j++) {
      res[k++] = bucket[j];
    }
  }

  return res;
}

// 插入排序函数，对桶中的元素进行排序
function insertionSort(array: number[]): void {
  const n = array.length;
  for (let i = 1; i < n; i++) {
    const key = array[i];
    let j = i - 1;
    while (j >= 0 && array[j] > key) {
      array[j + 1] = array[j];
      j--;
    }
    array[j + 1] = key;
  }
}

// testSort(bucketSort)


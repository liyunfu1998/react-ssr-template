import { swap, testSort } from './utils'
import { measureSort } from 'hy-algokit'

export default function heapSort(arr: number[]): number[] {
  const n = arr.length

  // 1.原地建堆: 从非叶子节点开始
  const start = Math.floor((n / 2) - 1)
  for (let i = start; i >=0; i--) {
    heapify_down(arr, n, i)
  }

  // 2.依次取出堆顶元素(根节点元素)并且放到正确的位置上
  for (let i = n - 1; i > 0; i--) {
    swap(arr, 0, i) // 0位置和最后位置进行交换
    // 执行删除后的操作
    heapify_down(arr, i, 0)
  }
  return arr
}

function heapify_down(arr: number[], n: number, index: number) {
  while (2 * index + 1 < n) {
    let leftChildIndex = 2 * index + 1
    let rightChildIndex = 2 * index + 2
    // 找到较大的索引
    let largerIndex = leftChildIndex
    if (rightChildIndex < n && arr[rightChildIndex] > arr[leftChildIndex]) {
      largerIndex = rightChildIndex
    }

    if (arr[index] >= arr[largerIndex]) {
      break
    }
    swap(arr, index, largerIndex)
    index = largerIndex
  }
}

// testSort(heapSort)
// measureSort(heapSort)

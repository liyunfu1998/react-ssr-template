import LinkeList from "../03_链表结构LinkedList2/16_实现LinkedList(代码重构)";

class CircularLinkedList<T> extends LinkeList<T> {
  append(value: T): void {
    super.append(value)
    this.tail!.next = this.head
  }

  insert(value: T, position: number): boolean {
    const isSuccess = super.insert(value, position)
    if (isSuccess && (position === 0 || position === this.length - 1)) {
      this.tail!.next = this.head
    }

    return isSuccess
  }

  removeAt(position: number): T | null {
    const value = super.removeAt(position)
    if (value && this.length && (position === 0 || position === this.length)) {
      this.tail!.next = this.head
    }

    return value
  }
}

const linkedList = new CircularLinkedList()
console.log('------------ 测试append ------------')
linkedList.append("aaa")
linkedList.append("bbb")
linkedList.append("ccc")
linkedList.append("ddd")
linkedList.traverse()

console.log('------------ 测试insert ------------')
linkedList.insert("abc", 0)
linkedList.traverse()
linkedList.insert("cba", 2)
linkedList.insert("nba", 6)
linkedList.traverse()

// 测试删除节点
console.log('------------ 测试removeAt ------------')
linkedList.removeAt(0)
linkedList.removeAt(0)
linkedList.traverse()
console.log(linkedList.removeAt(2))
linkedList.traverse()
console.log(linkedList.removeAt(3))
linkedList.traverse()

console.log('------------ 测试get ------------')
console.log(linkedList.get(0))
console.log(linkedList.get(1))
console.log(linkedList.get(2))

console.log('------------ 测试update ------------')
linkedList.update("why", 1)
linkedList.update("kobe", 2)
linkedList.traverse()

console.log('------------ 测试indexOf ------------')
console.log(linkedList.indexOf("cba"))
console.log(linkedList.indexOf("why"))
console.log(linkedList.indexOf("kobe"))
console.log(linkedList.indexOf("james"))

console.log('------------ 测试remove ------------')
console.log(linkedList.remove("why"))
linkedList.traverse()
console.log(linkedList.remove("cba"))
console.log(linkedList.remove("kobe"))
linkedList.traverse()
// console.log(linkedList.isEmpty())

import LinkedList from "../03_链表结构LinkedList/16_实现LinkedList(接口设计)";
import { LinkedNode } from '../types/LinkedNode'

class CircularLinkedList<T> extends LinkedList<T> {

  private isLastNode(current: LinkedNode<T>) {
    return current.next === this.head
  }

  private get lastNode() {
    let current = this.head
    while (current && !this.isLastNode(current)) {
      current = current.next
    }
    return current
  }

  // 重写一些方法
  append(value: T): void {
    const newNode = new LinkedNode(value)
    if (!this.head) {
      this.head = newNode
    } else {
      let current = this.head
      while (current.next && !this.isLastNode(current)) {
        current = current.next
      }
      current.next = newNode
    }
    newNode.next = this.head

    this.length++
  }

  // 遍历方法
  traverse(): void {
    if (!this.head) return

    const values: T[] = []
    let current: LinkedNode<T> | null = this.head
    while (current) {
      values.push(current.value)
      if (!this.isLastNode(current)) {
        current = current.next
      } else {
        current = null
      }
    }
    values.push(this.head.value)
    console.log(values.join("->"))
  }
}

const linkedList = new CircularLinkedList<string>()
console.log('------------ 测试append ------------')
linkedList.append("aaa")
linkedList.append("bbb")
linkedList.append("ccc")
linkedList.append("ddd")
linkedList.traverse()

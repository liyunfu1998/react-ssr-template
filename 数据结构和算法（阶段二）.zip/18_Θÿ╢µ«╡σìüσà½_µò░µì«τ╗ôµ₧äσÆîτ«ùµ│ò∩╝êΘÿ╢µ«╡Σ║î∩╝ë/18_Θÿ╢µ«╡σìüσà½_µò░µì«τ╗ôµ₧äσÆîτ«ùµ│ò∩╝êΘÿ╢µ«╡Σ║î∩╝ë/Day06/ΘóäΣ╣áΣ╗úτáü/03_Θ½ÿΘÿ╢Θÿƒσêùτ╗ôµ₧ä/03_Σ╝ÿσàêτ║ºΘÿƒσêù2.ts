import ArrayQueue from '../02_队列结构Queue/01_实现队列结构Queue'
import IQueue from '../02_队列结构Queue/IQueue'
import Heap from '../08_二叉堆(Heap)/04_堆结构Heap(原地建堆)'
import Node from '../types2/Node'


class PriorityQueue<T> extends ArrayQueue<T> {
  private heap: Heap<T> = new Heap()

  enqueue(element: T): void {
    this.heap.insert(element)
  }

  dequeue(): T | undefined {
    return this.heap.delete() ?? undefined
  }

  peek(): T | undefined {
    return this.heap.peek() ?? undefined
  }

  isEmpty() {
    return this.heap.isEmpty()
  }

  size(): number {
    return this.heap.length
  }
}

class Person {
  name: string
  age: number
  constructor(name: string, age: number) {
    this.name = name
    this.age = age
  }

  valueOf() {
    return this.age
  }
}

const priorityQueue = new PriorityQueue<Person>()
priorityQueue.enqueue(new Person("why", 18))
priorityQueue.enqueue(new Person("kobe", 30))
priorityQueue.enqueue(new Person("james", 25))

while (!priorityQueue.isEmpty()) {
  const p = priorityQueue.dequeue()
  console.log(`name:${p?.name} - age:${p?.age}`)
}

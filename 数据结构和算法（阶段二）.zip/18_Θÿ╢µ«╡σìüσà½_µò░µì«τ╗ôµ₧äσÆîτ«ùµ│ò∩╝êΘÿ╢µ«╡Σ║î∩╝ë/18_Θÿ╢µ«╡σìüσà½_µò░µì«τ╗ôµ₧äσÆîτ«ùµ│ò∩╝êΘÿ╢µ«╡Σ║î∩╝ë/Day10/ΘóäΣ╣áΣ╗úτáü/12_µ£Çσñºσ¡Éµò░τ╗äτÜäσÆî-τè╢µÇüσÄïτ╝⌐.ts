function maxSubArray(nums: number[]): number {
  // 1.获取数组的长度
  const n = nums.length

  // 2.定义保存状态的数组(或者命名为curSum)
  let preSum = nums[0]
  
  // 3.从索引值1个开始计算
  let max = preSum
  for (let i = 1; i < n; i++) {
    const value1 = nums[i] // 当前位置的值
    const value2 = preSum + nums[i] // +前一个的值
    preSum = Math.max(value1, value2)

    // 原来的max和最新的dp[i]进行比较
    max = Math.max(max, preSum)
  }

  return max
}

console.log(maxSubArray([-2,1,-3,4,-1,2,1,-5,4]))

export {}

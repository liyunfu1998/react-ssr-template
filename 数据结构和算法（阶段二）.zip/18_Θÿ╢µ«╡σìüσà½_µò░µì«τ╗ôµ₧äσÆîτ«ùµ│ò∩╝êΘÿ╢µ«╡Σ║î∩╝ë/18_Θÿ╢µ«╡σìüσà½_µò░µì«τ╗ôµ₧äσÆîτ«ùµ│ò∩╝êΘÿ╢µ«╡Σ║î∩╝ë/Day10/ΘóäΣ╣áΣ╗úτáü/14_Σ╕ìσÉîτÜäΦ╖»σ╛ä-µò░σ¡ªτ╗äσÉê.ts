function uniquePaths(m: number, n: number): number {
  // 总共需要走的步数
  const total = m + n - 2;
  // 向下走的步数
  const down = n - 1;
  // 不同路径的数目
  let ans = 1;
  // 使用组合数学的方法计算不同路径数目
  for (let i = 1; i <= down; i++) {
    ans *= total - down + i; // C(total-down+i, i)的分子
    ans /= i; // C(total-down+i, i)的分母
  }
  // 返回计算结果
  return ans;
}

function rob(nums: number[]): number {
  const n = nums.length
  if (n === 0) return 0
  if (n === 1) return nums[0]

  // 初始化dp状态数组
  const dp: number[] = new Array(n + 1)
  dp[0] = 0 // 0表示没有打劫
  dp[1] = nums[0] // 1表示打劫一个屋子
  for (let i = 2; i <= n ; i++) {
    dp[i] = Math.max(dp[i - 2] + nums[i - 1], dp[i - 1])
  }

  return dp[n]
}

export {}

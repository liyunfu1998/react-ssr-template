import { btPrint } from "hy-algokit"

class Node<T> {
  value: T
  constructor(value: T) {
    this.value = value
  }
}


export class TreeNode<T> extends Node<T> {
  left: TreeNode<T> | null = null
  right: TreeNode<T> | null = null

  // 当前节点的父节点
  parent: TreeNode<T> | null = null

  // 判断当前节点是父节点的左子节点
  get isLeft(): boolean {
    return !!(this.parent && this.parent.left === this)
  }

  // 判断当前节点是父节点的右子节点
  get isRight(): boolean {
    return !!(this.parent && this.parent.right === this)
  }
}

class AVLTreeNode<T> extends TreeNode<T> {
  left: AVLTreeNode<T> | null = null
  right: AVLTreeNode<T> | null = null
  parent: AVLTreeNode<T> | null = null

  private getHeight(): number {
    const leftHeight = this.left ? this.left.getHeight() : 0;
    const rightHeight = this.right ? this.right.getHeight() : 0;

    return Math.max(leftHeight, rightHeight) + 1;
  }

  public getBalanceFactor(): number {
    const leftHeight = this.left ? this.left.getHeight() : 0;
    const rightHeight = this.right ? this.right.getHeight() : 0;
    return leftHeight - rightHeight;
  }

  public get isBalanced(): boolean {
    const balanceFactor = this.getBalanceFactor();
    return balanceFactor >= -1 && balanceFactor <= 1;
  }

  public get higherChild(): AVLTreeNode<T> | null {
    let leftHeight = this.left ? this.left.getHeight(): 0
    let rightHeight = this.right ? this.right.getHeight(): 0
    if (leftHeight > rightHeight) return this.left
    if (leftHeight < rightHeight) return this.right
    // 高度一样, 返回同方向节点
    return this.left ? this.left: this.right
  }


  public rotateRight(): AVLTreeNode<T> {
    const isLeft = this.isLeft
    const isRight = this.isRight

    // 1.选择当前节点的左子节点作为旋转轴心(pivot)
    const pivot = this.left!
    // 2.pivot的父节点指向this(root)当前节点的父节点
    pivot.parent = this.parent

    // 3.this(root)当前节点的左节点, 指向pivot的右节点
    this.left = pivot.right
    // 4.如果右节点有值, 那么右节点的父节点指向this节点
    if (pivot.right) {
      pivot.right.parent = this
    }

    // 5.pivot的右节点指向this
    pivot.right = this
    // 6.this节点的父节点指向pivot
    this.parent = pivot

    // 7.判断是否有父节点, 父节点的left/right指向pivot
    if (!pivot.parent) {
      return pivot
    } else if (isLeft) {
      pivot.parent.left = pivot
    } else if (isRight) {
      pivot.parent.right = pivot
    }
    return pivot
  }


  public rotateLeft(): AVLTreeNode<T> {
    const isLeft = this.isLeft
    const isRight = this.isRight

    // 1.选择当前节点的右子节点作为旋转轴心(pivot)
    const pivot = this.right!
    // 2.pivot的父节点指向this(root)当前节点的父节点
    pivot.parent = this.parent


    // 3.this(root)当前节点的右节点, 指向pivot的左节点
    this.right = pivot.left
    // 4.如果左节点有值, 那么左节点的父节点指向this节点
    if (pivot.left) {
      pivot.left.parent = this
    }

    // 5.pivot的左节点指向this
    pivot.left = this
    // 6.this节点的父节点指向pivot
    this.parent = pivot

    // 7.判断是否有父节点, 父节点的left/right指向pivot
    if (!pivot.parent) {
      return pivot
    } else if (isLeft) {
      pivot.parent.left = pivot
    } else if (isRight) {
      pivot.parent.right = pivot
    }
    return pivot
  }
}

export default AVLTreeNode



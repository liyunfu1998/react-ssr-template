import BSTree from "./11_二叉搜索树BSTree(删除-代码重构)";
import AVLTreeNode from "./AVLTreeNode";

class AVLTree<T> extends BSTree<T> {
  rebalance(grand: AVLTreeNode<T>) {
    // 1.获取到父节点parent/current
    const parent = grand.higherChild
    const current = parent?.higherChild

    let resultNode: AVLTreeNode<T> | null = null
    // 2.判断属于哪一种情况: LL/RR/LR/RL
    if (parent?.isLeft) { // L
      if (current?.isLeft) { // L
        resultNode = grand.rotateRight()
      } else { // LR
        parent.rotateLeft()
        resultNode = grand.rotateRight()
      }
    } else { // R
      if (current?.isLeft) { // RL
        parent?.rotateRight()
        resultNode = grand.rotateLeft()
      } else { // RR
        resultNode = grand.rotateLeft()
      }
    }
    if (resultNode.parent === null) {
      this.root = resultNode
    }
  }

  protected createNode(value: T): AVLTreeNode<T> {
    return new AVLTreeNode(value)
  }

  protected checkBalance(currentNode: AVLTreeNode<T>, isAdd = true): void {
    let current = currentNode.parent
    while (current) {
      // 找到不平衡的节点后, 就让它恢复平衡
      if (!current.isBalanced) {
        this.rebalance(current)
        if (isAdd) break
      }
      current = current.parent
    }
  }
}

const avltree = new AVLTree<number>()
const nums: number[] = []
for (let i = 0; i < 20; i++) {
  const num = Math.ceil(Math.random() * 200)
  if (i < 10) nums.push(num)
  avltree.insert(num)
}

avltree.print()

for (const item of nums) {
  console.log("删除节点:", item)
  avltree.remove(item)
  avltree.print()
}

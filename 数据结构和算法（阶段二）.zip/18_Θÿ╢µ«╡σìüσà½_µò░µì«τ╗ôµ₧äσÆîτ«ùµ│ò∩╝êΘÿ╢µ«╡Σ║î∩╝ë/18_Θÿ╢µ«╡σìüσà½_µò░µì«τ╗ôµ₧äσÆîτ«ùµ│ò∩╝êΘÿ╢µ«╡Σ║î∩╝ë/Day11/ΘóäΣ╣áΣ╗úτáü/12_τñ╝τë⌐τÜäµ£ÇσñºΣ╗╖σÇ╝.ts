function maxValue(grid: number[][]): number {
  // 1.获取m*n
  const m = grid.length
  const n = grid[0].length

  // 2.初始化dp保存每个格子的最大值
  const dp: number[][] = Array.from({ length: m }, () => {
    return Array(n).fill(0)
  })
  dp[0][0] = grid[0][0]

  // 3.设置初始化值
  for (let i = 1; i < m; i++) {
    dp[i][0] = dp[i-1][0] + grid[i][0]
  }
  for (let j = 1; j < n; j++) {
    dp[0][j] = dp[0][j-1] + grid[0][j]
  }

  // 4.遍历每个位置, 求出最大值
  for (let i = 1; i < m; i++) {
    for (let j = 1; j < n; j++) {
      dp[i][j] = Math.max(dp[i-1][j], dp[i][j-1]) + grid[i][j]
    }
  }
  return dp[m-1][n-1]
}
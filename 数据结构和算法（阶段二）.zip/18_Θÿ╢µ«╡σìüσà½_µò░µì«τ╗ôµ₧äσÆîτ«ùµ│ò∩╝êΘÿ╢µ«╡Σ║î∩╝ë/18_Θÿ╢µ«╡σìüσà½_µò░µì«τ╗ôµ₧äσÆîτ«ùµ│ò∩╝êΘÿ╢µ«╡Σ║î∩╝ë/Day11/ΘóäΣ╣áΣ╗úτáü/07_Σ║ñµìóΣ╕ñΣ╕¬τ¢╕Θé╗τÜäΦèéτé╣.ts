import { ListNode } from "./Node";

function swapParis(head: ListNode | null): ListNode | null {
  const dummy = new ListNode(0)
  dummy.next = head

  let cur = dummy
  while (cur.next && cur.next.next) {
    const node1 = cur.next
    const node2 = cur.next.next

    cur.next = node2
    node1.next = node2.next
    node2.next = node1

    cur = node1
  }

  return dummy.next
}
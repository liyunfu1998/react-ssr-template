import { TreeNode } from './Node'

function invertTree(root: TreeNode | null): TreeNode | null {
  if (!root) return null

  const queue = [root]
  while (queue.length) {
    const node = queue.shift()!
    const temp = node.left
    node.left = node.right
    node.right = temp

    if (node.left) {
      queue.push(node.left)
    }
    if (node.right) {
      queue.push(node.right)
    }
  }
  return root
}

export {}

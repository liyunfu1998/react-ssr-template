import { TreeNode } from "./Node";

function flatten(root: TreeNode | null): void {
  if (root === null) return

  const stack = [root]
  let prev: TreeNode | null = null
  
  while (stack.length) {
    const curr = stack.pop()!
    if (prev !== null) {
      prev.left = null
      prev.right = curr
    }

    const left = curr.left
    const right = curr.right
    if (right) {
      stack.push(right)
    }
    if (left) {
      stack.push(left)
    }

    prev = curr
  }
}